
adil = int (input ('hi hello '))
arr= []
for i in range (d1+1):
    arr.append(int(input()))
 